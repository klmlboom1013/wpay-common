package com.wpay.common.templates.domain;

import lombok.*;
import lombok.extern.log4j.Log4j2;

@Log4j2
@Builder
@Value
@Getter
@ToString
@EqualsAndHashCode(callSuper = false)
public class DefaultWindow {



}
